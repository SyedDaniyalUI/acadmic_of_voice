(function() {
   //Adding zero prefix for numbers less than 10
  function formatZeroPrefix(value) {
    if (value < 10) {
      value = '0' + value;
    }
    return value;
  }

   //Countdown that restarts every midnight
  // Dispays hours, minutes and seconds
  function startMidnightCountdown() {
    var hoursElements = document.querySelectorAll('.hours');
    var minutesElements = document.querySelectorAll('.minutes');
    var secondsElements = document.querySelectorAll('.seconds');

    function calculateTimeLeft() {
      var now = new Date();
      var hoursleft = formatZeroPrefix(23 - now.getHours());
      var minutesleft = formatZeroPrefix(59 - now.getMinutes());
      var secondsleft = formatZeroPrefix(59 - now.getSeconds());

      for (var i=0; i < hoursElements.length; i++) {
        var hoursElement = hoursElements[i];
        var minutesElement = minutesElements[i];
        var secondsElement = secondsElements[i];
        hoursElement.textContent = hoursleft;
        minutesElement.textContent = minutesleft;
        secondsElement.textContent = secondsleft;
      }
    }

    calculateTimeLeft();
    setInterval(calculateTimeLeft, 1000);
  }

  document.addEventListener('DOMContentLoaded', startMidnightCountdown);

})()